### R code from vignette source 'MIHD.Rnw'

###################################################
### code chunk number 1: MIHD.Rnw:34-35
###################################################
library('MIHD')


###################################################
### code chunk number 2: MIHD.Rnw:38-41
###################################################
data(datagaussian)
data(databinary)
data(datapoisson)


###################################################
### code chunk number 3: MIHD.Rnw:44-46
###################################################
sum(is.na(datagaussian))
sum(is.na(datagaussian))/dim(datagaussian)[1]


###################################################
### code chunk number 4: MIHD.Rnw:51-52
###################################################
imp=MIdurr(data=datagaussian,method="lasso",family="gaussian",m=5)


###################################################
### code chunk number 5: MIHD.Rnw:55-58
###################################################
imp$n.missing
imp$col.missing
head(imp$impute)


###################################################
### code chunk number 6: MIHD.Rnw:63-68 (eval = FALSE)
###################################################
## MIdurr(data=datagaussian,method="adaptive lasso",family="gaussian")
## MIdurr(data=datagaussian,method="blasso",family="gaussian")
## MIdurr(data=databinary,method="lasso",family="binary")
## MIdurr(data=databinary,method="adaptive lasso",family="binary")
## MIdurr(data=databinary,method="blasso",family="binary")


###################################################
### code chunk number 7: MIHD.Rnw:71-73 (eval = FALSE)
###################################################
## MIiurr(data=datagaussian,method="lasso",family="gaussian")
## MIiurr(data=databinary,method="adaptive lasso",family="binary")


###################################################
### code chunk number 8: MIHD.Rnw:80-81
###################################################
data(GMdata)


###################################################
### code chunk number 9: MIHD.Rnw:85-86
###################################################
GM.imp=GMdurr(data=GMdata)


###################################################
### code chunk number 10: MIHD.Rnw:91-93
###################################################
imp=as.mice(data=GMdata,imp=GM.imp)
head(imp$nmis)


###################################################
### code chunk number 11: MIHD.Rnw:96-97
###################################################
imp$imp$z1


###################################################
### code chunk number 12: MIHD.Rnw:100-101 (eval = FALSE)
###################################################
## complete(imp)


###################################################
### code chunk number 13: MIHD.Rnw:106-107
###################################################
fit=with(imp,lm(z1~z2+z4))


###################################################
### code chunk number 14: MIHD.Rnw:110-111
###################################################
print(pool(fit))


###################################################
### code chunk number 15: MIHD.Rnw:114-118
###################################################
res <- summary(pool(fit))
numeric_cols <- sapply(res, is.numeric)
res[ , numeric_cols] <- round(res[ , numeric_cols], 3)
res


